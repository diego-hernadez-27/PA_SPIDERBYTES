/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author alesj
 */
public class consultas extends conexion{
    public boolean autenticacion(String usuario, String contraseña){
        PreparedStatement ps = null;
        ResultSet rs = null;
        try{
            String consulta = "Select * from usuarios where usuario = ? and contraseña = ?";
            
            ps = getConnection().prepareStatement(consulta);
            ps.setString(1, usuario);
            ps.setString(2, contraseña);
            rs = ps.executeQuery();
            
            if(rs.absolute(1)){
                return true;
                
            }
        } catch(SQLException e){
            System.out.println("Error"+ e);
            
        }finally{
            try{
            if(getConnection() != null) getConnection().close();
            if(ps != null) ps.close();
            if(rs != null) rs.close();
            }catch(Exception e){
            System.out.println("Error"+ e);
            }
            }
        
        
        
        return false;
    }
    public boolean registrar(String nombre, String apellido, String edad, String contraseña, String usuario, String correo){
        PreparedStatement ps = null;
        
        
        try{
            String consulta = "Insert into usuarios (nombre, apellido, edad, contraseña, usuario, correo) values(?,?,?,?,?,?)"; 
            ps = getConnection().prepareStatement(consulta);
            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setString(3, edad);
            ps.setString(4, contraseña);
            ps.setString(5, usuario);
            ps.setString(6, correo);
            if(ps.executeUpdate() == 1 ){
                return true;
                
            }
        
        }catch(SQLException e){
            System.out.println("Error" + e);
        }finally{
            try{
            if(getConnection() != null) getConnection().close();
            if(ps != null) ps.close();
            
            
            }catch(SQLException e){
                System.out.println("Error" + e);
            }
                
            }
             return false; 
        
    }
    
}
